<html>
<head>
<title>Display Data in DataTable Bootstrap</title>


<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css"/>
	<script src="js/jquery-1.12.3.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
	<style>
		#example 
		{
			width:1000px;
		}
	</style>
<!--submit data into mysql table-->
	<script>
	$(document).ready(function(){
	 $('#btn_submit').click(function(){
		 var ename = $("#employee_name").val();
		var designation = $("#designation").val();
		 var salary = $("#salary").val();
		 var joindate = $("#join_date").val();
		 
		 //insert data 
		 	 $.ajax({
                        url: 'process.php',
                        type: 'post',
                        data: {
                            "ename": ename,
							"salary" : salary,
							"designation" : designation,
							"joindate": joindate
                            
                        },
                        success: function(response) {
                           
                           $("#result").html(response);
							$('#example').DataTable();
                           
                        }
               });
		 
	 }) ;	
	});
	</script>

</head>
<body>
	<center>
	<div style="width:60%;padding:30px;text-align:left;	">
	Employee Name: <input type="text" class="form-control" name="employee_name" id="employee_name"/><br>
	Designation : <input type="text" class="form-control" name="designation" id="designation"/><br>
	Salary : 	<input type="text" class="form-control" name="salary" id="salary"/><br>
	Join Date : <input type="date" class="form-control" name="join_date"	id="join_date"/><br>
		<button type="button" class="btn btn-primary" name="btn_submit" id="btn_submit">Submit Data</button>
		
	</div>
		</center>
<div style="width:100%;padding:20px" id="result">
 
	</div>
</body>
</html>