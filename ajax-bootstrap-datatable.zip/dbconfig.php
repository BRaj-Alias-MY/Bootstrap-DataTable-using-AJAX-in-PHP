<?php 
$mysqli = new mysqli('localhost','root','root','test_db'); //correct db settings
?>